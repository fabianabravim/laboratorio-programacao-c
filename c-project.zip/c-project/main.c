// Compilador C online (editor)
// Escreva e execute programas em C online usando este editor.

#include <stdio.h>

int main(void) {
    int matriz[2][2] = {
        {10, 20},
        {30, 40}
    };

    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            printf("%d ", matriz[i][j]);
        }
        printf("\n");
    }

    return 0;
}
